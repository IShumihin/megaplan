from setuptools import setup, find_packages

setup(
    name='megaplan',
    version='1.1.1',
    packages=find_packages(),
    install_requires=['simplejson'],
    url='',
    license='',
    author='shuma',
    author_email='shmikhin.ivan@yandex.ru',
    description='megaplan api'
)
